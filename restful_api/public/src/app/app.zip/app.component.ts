import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  main_title = 'Restful Tasks API';
  tasks: any;
  one_task: any;
  num: number;
  randNum: number;
  str: string;
  first_name: string;

  constructor(private _httpService: HttpService) {}


  ngOnInit(){
    // this.getTasksFromService();
    
  }
  
  
  getTasksFromService() {
    let observable = this._httpService.getTasks();
    observable.subscribe(data => {
      console.log("Got our data!", data)
      this.tasks = data["task"];
    });
  }  

  getTaskFromService(id) {
    console.log("clicked")
    let observable = this._httpService.getTask(id);
    observable.subscribe(data => {
      console.log("Got an Id!", data);
      this.one_task = data["task"];
    });
  }

  // info(idx) {
  //   this.one_task = this.tasks[idx];
  // }
   

  
  // onButtonClickParam(num: Number) {
  //   console.log('click event is working with num param: ${num}');
  //   this._httpService.post
  // }
  // onButtonClickParam(num: Number, str: String) {
  //   console.log('click event is working with num param: ${num} and str param: ${str}')
  // }
  // onButtonClickEvent(event: any) { 
  //   console.log('click event is working with event: ${event}')

  // }

}
